import React, { useState, useRef } from 'react';
import { PlusCircle, Trash2, Receipt, Download, Edit2, Check, X } from 'lucide-react';
import { usePDF } from 'react-to-pdf';

interface PurchaseItem {
  id: string;
  description: string;
  quantity: number;
  unit: string;
  price: number;
  totalAmount: number;
}

const units = ['pieces', 'kg', 'g', 'L', 'mL', 'dozen'];

function App() {
  const [items, setItems] = useState<PurchaseItem[]>([]);
  const [description, setDescription] = useState('');
  const [quantity, setQuantity] = useState(1);
  const [unit, setUnit] = useState('pieces');
  const [totalAmount, setTotalAmount] = useState(0);
  const [includeGST, setIncludeGST] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editForm, setEditForm] = useState<PurchaseItem | null>(null);
  
  const { toPDF, targetRef } = usePDF({
    filename: 'purchase-statement.pdf',
    page: { margin: 20 }
  });

  const handleAddItem = (e: React.FormEvent) => {
    e.preventDefault();
    const unitPrice = quantity > 0 ? totalAmount / quantity : 0;
    const newItem: PurchaseItem = {
      id: crypto.randomUUID(),
      description,
      quantity,
      unit,
      price: unitPrice,
      totalAmount
    };
    setItems([...items, newItem]);
    resetForm();
  };

  const resetForm = () => {
    setDescription('');
    setQuantity(1);
    setUnit('pieces');
    setTotalAmount(0);
  };

  const handleRemoveItem = (id: string) => {
    setItems(items.filter(item => item.id !== id));
  };

  const startEditing = (item: PurchaseItem) => {
    setEditingId(item.id);
    setEditForm({ ...item });
  };

  const cancelEditing = () => {
    setEditingId(null);
    setEditForm(null);
  };

  const saveEdit = () => {
    if (editForm) {
      const updatedItems = items.map(item => 
        item.id === editingId ? {
          ...editForm,
          price: editForm.quantity > 0 ? editForm.totalAmount / editForm.quantity : 0
        } : item
      );
      setItems(updatedItems);
      setEditingId(null);
      setEditForm(null);
    }
  };

  const calculateUnitPrice = () => {
    if (quantity > 0) {
      return totalAmount / quantity;
    }
    return 0;
  };

  const subtotal = items.reduce((sum, item) => sum + item.totalAmount, 0);
  const tax = includeGST ? subtotal * 0.18 : 0; // 18% GST if enabled
  const total = subtotal + tax;

  return (
    <div className="min-h-screen bg-gray-50 py-8 px-4">
      <div className="max-w-4xl mx-auto">
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-2">
            <Receipt className="w-8 h-8 text-blue-600" />
            <h1 className="text-3xl font-bold text-gray-900">Purchase Statement Generator</h1>
          </div>
          {items.length > 0 && (
            <button
              onClick={() => toPDF()}
              className="flex items-center gap-2 px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700 transition-colors"
            >
              <Download className="w-5 h-5" />
              Download PDF
            </button>
          )}
        </div>

        <form onSubmit={handleAddItem} className="bg-white p-6 rounded-lg shadow-md mb-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Description
              </label>
              <input
                type="text"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                required
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                placeholder="Item description"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Quantity
              </label>
              <input
                type="number"
                value={quantity}
                onChange={(e) => setQuantity(Number(e.target.value))}
                min="0.01"
                step="0.01"
                required
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Unit
              </label>
              <select
                value={unit}
                onChange={(e) => setUnit(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                {units.map((u) => (
                  <option key={u} value={u}>
                    {u}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Total Amount (₹)
              </label>
              <input
                type="number"
                value={totalAmount}
                onChange={(e) => setTotalAmount(Number(e.target.value))}
                min="0"
                step="0.01"
                required
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
          </div>
          <div className="mt-4 flex items-center justify-between">
            <div className="text-sm text-gray-600">
              Unit Price: ₹{calculateUnitPrice().toFixed(2)}
            </div>
            <button
              type="submit"
              className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors"
            >
              <PlusCircle className="w-5 h-5" />
              Add Item
            </button>
          </div>
        </form>

        <div ref={targetRef} className="bg-white rounded-lg shadow-md overflow-hidden">
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Description</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Quantity</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Unit</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Unit Price</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Total</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {items.map((item) => (
                <tr key={item.id}>
                  {editingId === item.id ? (
                    <>
                      <td className="px-6 py-4">
                        <input
                          type="text"
                          value={editForm?.description}
                          onChange={(e) => setEditForm(prev => prev ? {...prev, description: e.target.value} : null)}
                          className="w-full px-2 py-1 border rounded"
                        />
                      </td>
                      <td className="px-6 py-4">
                        <input
                          type="number"
                          value={editForm?.quantity}
                          onChange={(e) => setEditForm(prev => prev ? {...prev, quantity: Number(e.target.value)} : null)}
                          min="0.01"
                          step="0.01"
                          className="w-20 px-2 py-1 border rounded"
                        />
                      </td>
                      <td className="px-6 py-4">
                        <select
                          value={editForm?.unit}
                          onChange={(e) => setEditForm(prev => prev ? {...prev, unit: e.target.value} : null)}
                          className="px-2 py-1 border rounded"
                        >
                          {units.map((u) => (
                            <option key={u} value={u}>{u}</option>
                          ))}
                        </select>
                      </td>
                      <td className="px-6 py-4">₹{(editForm?.totalAmount && editForm?.quantity ? editForm.totalAmount / editForm.quantity : 0).toFixed(2)}</td>
                      <td className="px-6 py-4">
                        <input
                          type="number"
                          value={editForm?.totalAmount}
                          onChange={(e) => setEditForm(prev => prev ? {...prev, totalAmount: Number(e.target.value)} : null)}
                          min="0"
                          step="0.01"
                          className="w-24 px-2 py-1 border rounded"
                        />
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="flex gap-2">
                          <button onClick={saveEdit} className="text-green-600 hover:text-green-800">
                            <Check className="w-5 h-5" />
                          </button>
                          <button onClick={cancelEditing} className="text-red-600 hover:text-red-800">
                            <X className="w-5 h-5" />
                          </button>
                        </div>
                      </td>
                    </>
                  ) : (
                    <>
                      <td className="px-6 py-4 whitespace-nowrap">{item.description}</td>
                      <td className="px-6 py-4 whitespace-nowrap">{item.quantity}</td>
                      <td className="px-6 py-4 whitespace-nowrap">{item.unit}</td>
                      <td className="px-6 py-4 whitespace-nowrap">₹{item.price.toFixed(2)}</td>
                      <td className="px-6 py-4 whitespace-nowrap">₹{item.totalAmount.toFixed(2)}</td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="flex gap-2">
                          <button
                            onClick={() => startEditing(item)}
                            className="text-blue-600 hover:text-blue-800"
                          >
                            <Edit2 className="w-5 h-5" />
                          </button>
                          <button
                            onClick={() => handleRemoveItem(item.id)}
                            className="text-red-600 hover:text-red-800"
                          >
                            <Trash2 className="w-5 h-5" />
                          </button>
                        </div>
                      </td>
                    </>
                  )}
                </tr>
              ))}
            </tbody>
          </table>

          <div className="p-6 bg-gray-50">
            <div className="flex justify-end">
              <div className="w-64">
                <div className="flex justify-between mb-2">
                  <span className="font-medium">Subtotal:</span>
                  <span>₹{subtotal.toFixed(2)}</span>
                </div>
                <div className="flex items-center justify-between mb-2">
                  <label className="flex items-center gap-2">
                    <input
                      type="checkbox"
                      checked={includeGST}
                      onChange={(e) => setIncludeGST(e.target.checked)}
                      className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                    />
                    <span className="font-medium">Include GST (18%)</span>
                  </label>
                  {includeGST && <span>₹{tax.toFixed(2)}</span>}
                </div>
                <div className="flex justify-between pt-2 border-t border-gray-200">
                  <span className="font-bold">Total:</span>
                  <span className="font-bold">₹{total.toFixed(2)}</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;